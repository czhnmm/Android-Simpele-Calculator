package com.example.ly_conedemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView tv_result;
    private String firstNum = "";
    private String operator = "";
    private String secondNum = "";
    private String result = "";
    private String showText = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv_result = findViewById(R.id.tv_result);
        Button but_add = findViewById(R.id.but_add);
        Button but_del = findViewById(R.id.but_del);
        Button but_sub = findViewById(R.id.but_sub);
        Button but_multi = findViewById(R.id.but_multi);
        Button but_div = findViewById(R.id.but_div);
        Button but_clear = findViewById(R.id.but_clear);
        Button but_recip = findViewById(R.id.but_recip);
        Button but_point = findViewById(R.id.but_point);
        Button but_eq = findViewById(R.id.but_eq);
        Button num_0 = findViewById(R.id.num_0);
        Button num_1 = findViewById(R.id.num_1);
        Button num_2 = findViewById(R.id.num_2);
        Button num_3 = findViewById(R.id.num_3);
        Button num_4 = findViewById(R.id.num_4);
        Button num_5 = findViewById(R.id.num_5);
        Button num_6 = findViewById(R.id.num_6);
        Button num_7 = findViewById(R.id.num_7);
        Button num_8 = findViewById(R.id.num_8);
        Button num_9 = findViewById(R.id.num_9);
        ImageButton img_but = findViewById(R.id.img_but);

        but_eq.setOnClickListener(this);
        but_sub.setOnClickListener(this);
        but_point.setOnClickListener(this);
        but_recip.setOnClickListener(this);
        but_clear.setOnClickListener(this);
        but_add.setOnClickListener(this);
        but_del.setOnClickListener(this);
        but_div.setOnClickListener(this);
        but_multi.setOnClickListener(this);
        
        num_0.setOnClickListener(this);
        num_1.setOnClickListener(this);
        num_2.setOnClickListener(this);
        num_3.setOnClickListener(this);
        num_4.setOnClickListener(this);
        num_5.setOnClickListener(this);
        num_6.setOnClickListener(this);
        num_7.setOnClickListener(this);
        num_8.setOnClickListener(this);
        num_9.setOnClickListener(this);
        img_but.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        String inputText;
        if(view.getId() == R.id.img_but){
            inputText = "√";
        }else{
            inputText = ((TextView)view).getText().toString();
        }
        if(view.getId() == R.id.but_clear){
            clear();
        }
        if(view.getId() == R.id.but_add){
            operator = inputText;
        } else if (view.getId() == R.id.but_sub) {
            operator = inputText;
        } else if (view.getId() == R.id.but_multi) {
            operator = inputText;
        } else if (view.getId() == R.id.but_div) {
            operator = inputText;
        } else if (view.getId() == R.id.but_eq){
            refleshText(showText + inputText);
            Toast.makeText(this,"第二位操作数："+secondNum,Toast.LENGTH_SHORT).show();
            double cal_result = cal();
            firstNum = String.valueOf(cal_result);
            secondNum = "";
            refleshText(showText + cal_result);
        } else if (view.getId() == R.id.but_recip) {
            Toast.makeText(this,"进行倒数运算",Toast.LENGTH_SHORT).show();
            double cal_result = 1 / Double.parseDouble(firstNum);
            firstNum = String.valueOf(cal_result);
            refleshText(" 1  / " + showText + " = " + cal_result);
        } else if (view.getId() == R.id.img_but) {
            Toast.makeText(this,"进行开根运算",Toast.LENGTH_SHORT).show();
            double cal_result = Math.sqrt(Double.parseDouble(firstNum));
            firstNum = String.valueOf(cal_result);
            refleshText(showText + inputText + " = "+ cal_result);
        } else if (view.getId() == R.id.but_del) {
            tv_result.setText(del(showText));
        }
        if (view.getId() != R.id.but_del && view.getId() != R.id.but_clear
        && view.getId() != R.id.but_recip && view.getId() != R.id.but_eq){
            refleshText(showText + inputText);
            if (operator.equals("")){
                firstNum += inputText;
            }else {
                Toast.makeText(this,"第一位操作数："+firstNum,Toast.LENGTH_SHORT).show();
                if (!inputText.equals("+") && !inputText.equals("-")
                && !inputText.equals("X") && !inputText.equals("/")
                && !inputText.equals("=") ){
                    secondNum += inputText;
                }
            }
        }
    }
    public void refleshText(String text){
        showText = text;
        tv_result.setText(showText);
    }
    public void clear(){
        showText = "";
        firstNum = "";
        secondNum = "";
        operator = "";
        tv_result.setText("0");
    }
    public double cal(){
        switch (operator){
            case "+" :
                return Double.parseDouble(firstNum) + Double.parseDouble(secondNum);
            case "-" :
                return Double.parseDouble(firstNum) - Double.parseDouble(secondNum);
            case "X":
                return Double.parseDouble(firstNum) * Double.parseDouble(secondNum);
            default:
                return Double.parseDouble(firstNum) / Double.parseDouble(secondNum);
        }
    }
    public String del(String Text){
        showText = Text.substring(0,showText.length()-1);
        return showText;
    }
}